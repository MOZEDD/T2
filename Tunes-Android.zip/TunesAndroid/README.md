# Tunes (native Android)

Kotlin + Jetpack Compose + Media3. Plays music already on your phone, shows embedded cover art, plays in the background with a media notification.

## Performance optimizations

- Removed expensive full-list blur under the mini player (main source of scroll lag)
- Lightweight mini player with simple elevation instead of heavy blur + ghost list
- Art loading uses RGB_565 for small covers, lower concurrency, and better downsampling
- Position updates only while playing (no constant polling when paused)
- Filtered library list uses `derivedStateOf` to avoid unnecessary recomputation
- LazyColumn contentType + stable keys for smoother recycling
- R8 full mode + resource shrinking enabled for release APKs

## Build the APK

**Android Studio:** File > Open this folder > Build > Build APK(s).  
Output: `app/build/outputs/apk/debug/app-debug.apk` (or release after signing)

**GitHub:** push this folder to a repo (branch `main`). Actions > "Build APK" runs automatically; download `Tunes-APK` from the run's Artifacts.
