# Keep Media3
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**

# Kotlin
-dontwarn kotlin.**
-keepclassmembers class **$WhenMappings { <fields>; }
-keepclassmembers class kotlin.Metadata { public <methods>; }

# Application
-keep class com.tunes.app.** { *; }
