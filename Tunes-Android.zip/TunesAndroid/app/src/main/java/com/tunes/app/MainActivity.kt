package com.tunes.app

import android.Manifest
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioManager
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.util.LruCache
import android.util.Size
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

val Accent = Color(0xFFFA2D55)

class Pal(val bg: Color, val card: Color, val tx: Color, val tx2: Color, val fill: Color)
val LightPal = Pal(Color(0xFFF2F2F7), Color.White, Color(0xFF111114), Color(0xFF8A8A92), Color(0x1F767680))
val DarkPal = Pal(Color.Black, Color(0xFF141416), Color(0xFFF5F5F7), Color(0xFF9A9AA1), Color(0x3D767680))
val LocalPal = staticCompositionLocalOf { LightPal }

data class Track(val id: Long, val title: String, val artist: String, val album: String, val dur: Long, val uri: Uri) {
    fun item(): MediaItem = MediaItem.Builder().setMediaId(id.toString()).setUri(uri)
        .setMediaMetadata(MediaMetadata.Builder().setTitle(title).setArtist(artist).setAlbumTitle(album).build()).build()
}

data class Pl(val id: String, val name: String, val ids: List<Long>)

data class AlbumEntry(val name: String, val artist: String, val count: Int)

/** Built-in playlist ids */
const val PL_RECENT = "recent"
const val PL_FAV = "fav"

fun loadPls(s: String?): List<Pl> = try {
    if (s == null) emptyList() else {
        val a = JSONArray(s)
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i); val ia = o.getJSONArray("ids")
            Pl(o.getString("id"), o.getString("name"), (0 until ia.length()).map { ia.getLong(it) })
        }
    }
} catch (_: Exception) { emptyList() }

fun loadRecentIds(s: String?): List<Long> = try {
    if (s.isNullOrBlank()) emptyList()
    else {
        val a = JSONArray(s)
        (0 until a.length()).map { a.getLong(it) }
    }
} catch (_: Exception) { emptyList() }

fun fmt(ms: Long): String {
    val s = (ms.coerceAtLeast(0) / 1000).toInt()
    return "${s / 60}:${(s % 60).toString().padStart(2, '0')}"
}

fun loadTracks(c: Context): List<Track> {
    val out = ArrayList<Track>(512)
    val m = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    val proj = arrayOf(
        MediaStore.Audio.Media._ID,
        MediaStore.Audio.Media.TITLE,
        MediaStore.Audio.Media.ARTIST,
        MediaStore.Audio.Media.ALBUM,
        MediaStore.Audio.Media.DURATION
    )
    val sel = "${MediaStore.Audio.Media.IS_MUSIC}!=0 AND ${MediaStore.Audio.Media.DURATION}>=30000"
    c.contentResolver.query(m, proj, sel, null, "${MediaStore.Audio.Media.DATE_ADDED} DESC")?.use { q ->
        while (q.moveToNext()) {
            val id = q.getLong(0)
            val artist = q.getString(2)?.takeIf { it != "<unknown>" } ?: "Unknown Artist"
            out.add(
                Track(
                    id,
                    q.getString(1) ?: "Untitled",
                    artist,
                    q.getString(3)?.takeIf { it.isNotBlank() } ?: "Unknown Album",
                    q.getLong(4),
                    ContentUris.withAppendedId(m, id)
                )
            )
        }
    }
    return out
}

object ArtCache {
    private val small = LruCache<Long, Bitmap>(400)
    private val large = LruCache<Long, Bitmap>(6)
    private val none = java.util.Collections.synchronizedSet(HashSet<Long>())
    private val sem = Semaphore(2)

    private fun cacheFor(big: Boolean) = if (big) large else small

    fun peek(id: Long, big: Boolean): ImageBitmap? = cacheFor(big).get(id)?.asImageBitmap()

    suspend fun loadAsync(c: Context, t: Track, big: Boolean): ImageBitmap? =
        sem.withPermit { withContext(Dispatchers.IO) { load(c, t, big) } }

    private fun load(c: Context, t: Track, big: Boolean): ImageBitmap? {
        val cache = cacheFor(big)
        cache.get(t.id)?.let { return it.asImageBitmap() }
        if (t.id in none) return null

        val maxPx = if (big) 720 else 160
        var bm: Bitmap? = null
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(c, t.uri)
            val b = r.embeddedPicture
            if (b != null) {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(b, 0, b.size, o)
                var s = 1
                while (o.outWidth / (s * 2) >= maxPx || o.outHeight / (s * 2) >= maxPx) s *= 2
                val opts = BitmapFactory.Options().apply {
                    inSampleSize = s
                    inPreferredConfig = Bitmap.Config.RGB_565
                }
                bm = BitmapFactory.decodeByteArray(b, 0, b.size, opts)
            }
        } catch (_: Exception) {
        } finally {
            try { r.release() } catch (_: Exception) {}
        }

        if (bm == null && Build.VERSION.SDK_INT >= 29) {
            try {
                bm = c.contentResolver.loadThumbnail(t.uri, Size(maxPx, maxPx), null)
            } catch (_: Exception) {}
        }

        if (bm == null) {
            none.add(t.id)
            return null
        }
        if (!big && bm.config != Bitmap.Config.RGB_565) {
            val converted = bm.copy(Bitmap.Config.RGB_565, false)
            if (converted != null) {
                bm.recycle()
                bm = converted
            }
        }
        cache.put(t.id, bm)
        return bm.asImageBitmap()
    }
}

class PosState { var ms by mutableLongStateOf(0L) }

fun grad(id: Long): Brush {
    val h = ((id * 47) % 360).toFloat()
    return Brush.linearGradient(
        listOf(
            Color.hsv(h, .65f, .92f),
            Color.hsv((h + 50f) % 360f, .75f, .72f)
        )
    )
}

@Composable
fun Cover(t: Track?, modifier: Modifier, radius: Dp = 9.dp, big: Boolean = false) {
    val ctx = LocalContext.current
    var bmp by remember(t?.id, big) {
        mutableStateOf(t?.let { ArtCache.peek(it.id, big) ?: ArtCache.peek(it.id, false) })
    }
    LaunchedEffect(t?.id, big) {
        if (t != null && ArtCache.peek(t.id, big) == null) {
            if (!big) delay(80)
            val r = ArtCache.loadAsync(ctx, t, big)
            if (r != null) bmp = r
        }
    }
    val b = bmp
    Box(
        modifier.clip(RoundedCornerShape(radius)).background(grad(t?.id ?: 0L)),
        contentAlignment = Alignment.Center
    ) {
        if (b != null) {
            Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Icon(
                Icons.Rounded.MusicNote,
                null,
                tint = Color.White.copy(alpha = .9f),
                modifier = Modifier.fillMaxSize(.4f)
            )
        }
    }
}

@Composable
fun MiniBar(ps: PosState, total: Long, modifier: Modifier) {
    val frac = if (total > 0) (ps.ms.toFloat() / total).coerceIn(0f, 1f) else 0f
    Box(modifier.fillMaxWidth(frac).height(2.dp).background(Accent))
}

@Composable
fun Bar(
    frac: Float,
    fg: Color,
    thumb: Boolean,
    onChange: (Float) -> Unit,
    onDone: () -> Unit
) {
    var w by remember { mutableFloatStateOf(1f) }
    val change by rememberUpdatedState(onChange)
    val done by rememberUpdatedState(onDone)
    val f = frac.coerceIn(0f, 1f)
    val density = LocalDensity.current
    Box(
        Modifier
            .fillMaxWidth()
            .height(28.dp)
            .onSizeChanged { w = it.width.toFloat().coerceAtLeast(1f) }
            .pointerInput(Unit) {
                detectTapGestures { o ->
                    change((o.x / w).coerceIn(0f, 1f))
                    done()
                }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { o -> change((o.x / w).coerceIn(0f, 1f)) },
                    onDragEnd = { done() },
                    onDragCancel = { done() },
                    onHorizontalDrag = { ch, _ -> change((ch.position.x / w).coerceIn(0f, 1f)) }
                )
            },
        contentAlignment = Alignment.CenterStart
    ) {
        Box(Modifier.fillMaxWidth().height(4.dp).clip(CircleShape).background(fg.copy(alpha = .25f)))
        Box(Modifier.fillMaxWidth(f).height(4.dp).clip(CircleShape).background(fg))
        if (thumb) {
            val half = with(density) { 7.dp.toPx() }
            Box(
                Modifier
                    .offset { IntOffset((f * w - half).roundToInt(), 0) }
                    .size(14.dp)
                    .clip(CircleShape)
                    .background(fg)
            )
        }
    }
}

@Composable
fun PlayerSeek(
    ps: PosState,
    total: Long,
    fg: Color,
    onDrag: () -> Unit,
    onDone: (Long) -> Unit
) {
    val frac = if (total > 0) ps.ms.toFloat() / total else 0f
    Column {
        Bar(frac, fg, true, { f ->
            onDrag()
            ps.ms = (f * total).toLong()
        }, { onDone(ps.ms) })
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(fmt(ps.ms), color = fg.copy(alpha = .6f), fontSize = 13.sp)
            Text("-" + fmt(total - ps.ms), color = fg.copy(alpha = .6f), fontSize = 13.sp)
        }
    }
}

@Composable
fun coverColor(t: Track): Color {
    val ctx = LocalContext.current
    val fb = remember(t.id) { Color.hsv(((t.id * 47) % 360).toFloat(), .6f, .55f) }
    var col by remember(t.id) { mutableStateOf(fb) }
    LaunchedEffect(t.id) {
        val avg = withContext(Dispatchers.IO) {
            try {
                val img = ArtCache.peek(t.id, false) ?: ArtCache.loadAsync(ctx, t, false)
                if (img == null) null else {
                    val src = img.asAndroidBitmap()
                    val b = Bitmap.createScaledBitmap(src, 8, 8, true)
                    var r = 0; var g = 0; var bl = 0
                    for (x in 0 until 8) for (y in 0 until 8) {
                        val px = b.getPixel(x, y)
                        r += android.graphics.Color.red(px)
                        g += android.graphics.Color.green(px)
                        bl += android.graphics.Color.blue(px)
                    }
                    if (b != src) b.recycle()
                    Color(r / 64, g / 64, bl / 64)
                }
            } catch (_: Exception) {
                null
            }
        }
        if (avg != null) col = avg
    }
    return animateColorAsState(col, tween(400), label = "cover").value
}

@Composable
fun IconBtn(
    icon: ImageVector,
    tint: Color? = null,
    box: Dp = 44.dp,
    size: Dp = 26.dp,
    onClick: () -> Unit
) {
    Box(
        Modifier.size(box).clip(CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, null, tint = tint ?: LocalPal.current.tx, modifier = Modifier.size(size))
    }
}

@Composable
fun Chip(label: String, on: Boolean, onClick: () -> Unit) {
    val p = LocalPal.current
    Box(
        Modifier
            .clip(RoundedCornerShape(18.dp))
            .background(if (on) Accent else p.fill)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 9.dp)
    ) {
        Text(
            label,
            color = if (on) Color.White else p.tx,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun TrackRow(
    t: Track,
    on: Boolean,
    showRemove: Boolean = false,
    onRemove: (() -> Unit)? = null,
    onClick: () -> Unit
) {
    val p = LocalPal.current
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(p.card)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                t.title,
                color = if (on) Accent else p.tx,
                fontSize = 17.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                t.artist,
                color = p.tx2,
                fontSize = 14.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.width(8.dp))
        Text(fmt(t.dur), color = p.tx2, fontSize = 15.sp)
        if (showRemove && onRemove != null) {
            Spacer(Modifier.width(4.dp))
            IconBtn(Icons.Rounded.Close, p.tx2, box = 36.dp, size = 20.dp, onClick = onRemove)
        }
    }
}

@Composable
fun GroupRow(title: String, subtitle: String, icon: ImageVector, onClick: () -> Unit) {
    val p = LocalPal.current
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(p.card)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(p.fill),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = Accent, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                title,
                color = p.tx,
                fontSize = 17.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(subtitle, color = p.tx2, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(Icons.Rounded.ChevronRight, null, tint = p.tx2, modifier = Modifier.size(22.dp))
    }
}

fun audioPerm() =
    if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
    else Manifest.permission.READ_EXTERNAL_STORAGE

fun hasAudioPerm(c: Context) =
    ContextCompat.checkSelfPermission(c, audioPerm()) == PackageManager.PERMISSION_GRANTED

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        requestMaxRefreshRate()
        setContent { TunesApp() }
    }

    private fun requestMaxRefreshRate() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
        val modes = display?.supportedModes ?: return
        val best = modes.maxByOrNull { it.refreshRate } ?: return
        val params = window.attributes
        params.preferredDisplayModeId = best.modeId
        params.preferredRefreshRate = best.refreshRate
        window.attributes = params
    }
}

/**
 * Navigation:
 *  tab: all | artists | albums | playlists
 *  detail:
 *    null
 *    artist:NAME
 *    album:NAME||ARTIST
 *    pl:recent | pl:fav | pl:USER_ID
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun TunesApp() {
    val ctx = LocalContext.current
    val pal = if (isSystemInDarkTheme()) DarkPal else LightPal
    val prefs = remember { ctx.getSharedPreferences("tunes", Context.MODE_PRIVATE) }

    var granted by remember { mutableStateOf(hasAudioPerm(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasAudioPerm(ctx)
    }
    LaunchedEffect(Unit) {
        if (!granted) {
            launcher.launch(
                if (Build.VERSION.SDK_INT >= 33)
                    arrayOf(audioPerm(), Manifest.permission.POST_NOTIFICATIONS)
                else arrayOf(audioPerm())
            )
        }
    }

    var tracks by remember { mutableStateOf(emptyList<Track>()) }
    var scanKey by remember { mutableIntStateOf(0) }
    LaunchedEffect(granted, scanKey) {
        if (granted) tracks = withContext(Dispatchers.IO) { loadTracks(ctx) }
    }

    var player by remember { mutableStateOf<Player?>(null) }
    DisposableEffect(Unit) {
        val f = MediaController.Builder(
            ctx,
            SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        ).buildAsync()
        f.addListener(
            { try { player = f.get() } catch (_: Exception) {} },
            ContextCompat.getMainExecutor(ctx)
        )
        onDispose { MediaController.releaseFuture(f) }
    }

    var curId by remember { mutableStateOf<Long?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var shuffle by remember { mutableStateOf(false) }
    var repeat by remember { mutableIntStateOf(Player.REPEAT_MODE_OFF) }
    var speed by remember { mutableFloatStateOf(1f) }
    var durMs by remember { mutableLongStateOf(0L) }
    val ps = remember { PosState() }
    var dragging by remember { mutableStateOf(false) }

    var favs by remember { mutableStateOf(prefs.getStringSet("fav", emptySet())!!.toSet()) }
    var recentIds by remember { mutableStateOf(loadRecentIds(prefs.getString("recent", null))) }
    var pls by remember { mutableStateOf(loadPls(prefs.getString("pls", null))) }

    fun saveRecent(ids: List<Long>) {
        recentIds = ids
        val a = JSONArray()
        ids.forEach { a.put(it) }
        prefs.edit().putString("recent", a.toString()).apply()
    }

    fun pushRecent(id: Long) {
        val next = (listOf(id) + recentIds.filter { it != id }).take(80)
        if (next != recentIds) saveRecent(next)
    }

    DisposableEffect(player) {
        val p = player
        if (p == null) {
            onDispose { }
        } else {
            fun sync() {
                val id = p.currentMediaItem?.mediaId?.toLongOrNull()
                if (id != null && id != curId) pushRecent(id)
                curId = id
                isPlaying = p.isPlaying
                shuffle = p.shuffleModeEnabled
                repeat = p.repeatMode
                speed = p.playbackParameters.speed
                durMs = p.duration.coerceAtLeast(0L)
            }
            val l = object : Player.Listener {
                override fun onEvents(pl: Player, events: Player.Events) { sync() }
            }
            p.addListener(l)
            sync()
            onDispose { p.removeListener(l) }
        }
    }

    LaunchedEffect(player, isPlaying, dragging) {
        val p = player ?: return@LaunchedEffect
        if (!isPlaying || dragging) return@LaunchedEffect
        while (true) {
            ps.ms = p.currentPosition
            delay(350)
        }
    }

    var query by remember { mutableStateOf("") }
    // Main tabs
    var tab by remember { mutableStateOf("all") } // all | artists | albums | playlists
    // Detail: null | artist:X | album:X||Y | pl:recent | pl:fav | pl:USERID
    var detail by remember { mutableStateOf<String?>(null) }
    val tabKeys = listOf("all", "artists", "albums", "playlists")
    val pagerState = rememberPagerState(
        initialPage = tabKeys.indexOf(tab).coerceAtLeast(0),
        pageCount = { tabKeys.size }
    )
    val pagerScope = rememberCoroutineScope()
    // Keep tab label in sync when user swipes
    LaunchedEffect(pagerState) {
        snapshotFlow { pagerState.currentPage }.collect { page ->
            val t = tabKeys[page]
            if (tab != t) tab = t
        }
    }
    var sort by remember { mutableIntStateOf(0) }
    var dlg by remember { mutableIntStateOf(0) } // 0 none, 1 new playlist, 2 add to playlist
    var pendingAdd by remember { mutableStateOf<Track?>(null) }
    var showPlayer by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    val trackById = remember(tracks) { tracks.associateBy { it.id } }

    val artists by remember {
        derivedStateOf {
            tracks.map { it.artist }.distinct().sortedBy { it.lowercase() }
        }
    }

    val albums by remember {
        derivedStateOf {
            tracks
                .groupBy { it.album to it.artist }
                .map { (k, v) -> AlbumEntry(k.first, k.second, v.size) }
                .sortedWith(compareBy({ it.name.lowercase() }, { it.artist.lowercase() }))
        }
    }

    fun playlistTracks(plId: String): List<Track> = when (plId) {
        PL_RECENT -> recentIds.mapNotNull { trackById[it] }
        PL_FAV -> tracks.filter { it.id.toString() in favs }
        else -> {
            val ids = pls.firstOrNull { it.id == plId }?.ids ?: emptyList()
            ids.mapNotNull { trackById[it] }
        }
    }

    val shown by remember {
        derivedStateOf {
            val base: List<Track> = when {
                detail?.startsWith("artist:") == true -> {
                    val name = detail!!.removePrefix("artist:")
                    tracks.filter { it.artist == name }
                }
                detail?.startsWith("album:") == true -> {
                    val rest = detail!!.removePrefix("album:")
                    val parts = rest.split("||", limit = 2)
                    val an = parts.getOrElse(0) { "" }
                    val ar = parts.getOrElse(1) { "" }
                    tracks.filter { it.album == an && it.artist == ar }
                }
                detail?.startsWith("pl:") == true -> {
                    playlistTracks(detail!!.removePrefix("pl:"))
                }
                else -> tracks // full library (All tab / pager page 0)
            }
            var l = base
            if (query.isNotBlank() && (tab == "all" || detail != null)) {
                val q = query
                l = l.filter {
                    it.title.contains(q, ignoreCase = true) ||
                        it.artist.contains(q, ignoreCase = true) ||
                        it.album.contains(q, ignoreCase = true)
                }
            }
            when (sort) {
                1 -> l.sortedBy { it.title.lowercase() }
                2 -> l.sortedWith(compareBy({ it.artist.lowercase() }, { it.title.lowercase() }))
                else -> l
            }
        }
    }

    val filteredArtists by remember {
        derivedStateOf {
            if (query.isBlank()) artists
            else artists.filter { it.contains(query, ignoreCase = true) }
        }
    }

    val filteredAlbums by remember {
        derivedStateOf {
            if (query.isBlank()) albums
            else albums.filter {
                it.name.contains(query, ignoreCase = true) ||
                    it.artist.contains(query, ignoreCase = true)
            }
        }
    }

    val cur = trackById[curId]
    val inDetail = detail != null
    BackHandler(enabled = showPlayer) { showPlayer = false }
    BackHandler(enabled = !showPlayer && inDetail) { detail = null }

    val total = if (durMs > 0) durMs else (cur?.dur ?: 0L)

    fun playFrom(list: List<Track>, i: Int) {
        val p = player ?: return
        if (list.isEmpty()) return
        p.setMediaItems(list.map { it.item() }, i, 0L)
        p.prepare()
        p.play()
    }

    fun toggleFav(t: Track) {
        val k = t.id.toString()
        favs = if (k in favs) favs - k else favs + k
        prefs.edit().putStringSet("fav", favs).apply()
    }

    fun togglePlay() {
        val p = player ?: return
        if (p.isPlaying) p.pause() else p.play()
    }

    fun savePls(l: List<Pl>) {
        pls = l
        val a = JSONArray()
        l.forEach { p ->
            a.put(JSONObject().put("id", p.id).put("name", p.name).put("ids", JSONArray(p.ids)))
        }
        prefs.edit().putString("pls", a.toString()).apply()
    }

    fun removeFromCurrentPlaylist(t: Track) {
        val d = detail ?: return
        when {
            d == "pl:$PL_FAV" -> toggleFav(t)
            d == "pl:$PL_RECENT" -> saveRecent(recentIds.filter { it != t.id })
            d.startsWith("pl:") -> {
                val id = d.removePrefix("pl:")
                savePls(pls.map {
                    if (it.id == id) it.copy(ids = it.ids - t.id) else it
                })
            }
        }
    }

    fun headerTitle(): String = when {
        detail?.startsWith("artist:") == true -> detail!!.removePrefix("artist:")
        detail?.startsWith("album:") == true -> detail!!.removePrefix("album:").substringBefore("||")
        detail == "pl:$PL_RECENT" -> "Recently Played"
        detail == "pl:$PL_FAV" -> "Favourites"
        detail?.startsWith("pl:") == true ->
            pls.firstOrNull { it.id == detail!!.removePrefix("pl:") }?.name ?: "Playlist"
        tab == "artists" -> "Artists"
        tab == "albums" -> "Albums"
        tab == "playlists" -> "Playlists"
        else -> "Library"
    }

    val canEditPlaylist = detail?.startsWith("pl:") == true

    CompositionLocalProvider(LocalPal provides pal) {
        Box(Modifier.fillMaxSize().background(pal.bg)) {
            Column(Modifier.fillMaxSize()) {
                // Header
                Row(
                    Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(start = 12.dp, end = 10.dp, top = 10.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (inDetail) {
                        IconBtn(Icons.Rounded.ArrowBack, box = 44.dp, size = 26.dp) { detail = null }
                    }
                    Text(
                        headerTitle(),
                        fontSize = if (inDetail) 26.sp else 34.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = pal.tx,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    if (detail == "pl:$PL_RECENT" && recentIds.isNotEmpty()) {
                        Text(
                            "Clear",
                            color = Accent,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier
                                .clickable { saveRecent(emptyList()) }
                                .padding(horizontal = 10.dp, vertical = 8.dp)
                        )
                    } else if (detail?.startsWith("pl:") == true &&
                        detail != "pl:$PL_RECENT" &&
                        detail != "pl:$PL_FAV"
                    ) {
                        Text(
                            "Delete",
                            color = Accent,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier
                                .clickable {
                                    val id = detail!!.removePrefix("pl:")
                                    detail = null
                                    savePls(pls.filter { it.id != id })
                                }
                                .padding(horizontal = 10.dp, vertical = 8.dp)
                        )
                    }
                }

                // Search
                Row(
                    Modifier
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .fillMaxWidth()
                        .height(46.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(pal.fill)
                        .padding(horizontal = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.Search, null, tint = pal.tx2, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Box(Modifier.weight(1f)) {
                        if (query.isEmpty()) {
                            Text("Search", color = pal.tx2, fontSize = 17.sp)
                        }
                        BasicTextField(
                            query,
                            { query = it },
                            singleLine = true,
                            textStyle = TextStyle(color = pal.tx, fontSize = 17.sp),
                            cursorBrush = SolidColor(Accent),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    if (query.isNotEmpty()) {
                        IconBtn(Icons.Rounded.Close, pal.tx2, box = 32.dp, size = 18.dp) { query = "" }
                    }
                }

                // Main tabs (hidden when in detail) — swipe content left/right also switches tabs
                if (!inDetail) {
                    Row(
                        Modifier
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 16.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        fun goTab(key: String) {
                            tab = key
                            detail = null
                            val idx = tabKeys.indexOf(key)
                            if (idx >= 0) pagerScope.launch {
                                pagerState.animateScrollToPage(idx)
                            }
                        }
                        Chip("All", tab == "all") { goTab("all") }
                        Chip("Artists", tab == "artists") { goTab("artists") }
                        Chip("Albums", tab == "albums") { goTab("albums") }
                        Chip("Playlists", tab == "playlists") { goTab("playlists") }
                        if (tab == "all") {
                            Chip(
                                listOf("Sort: Recent", "Sort: Title", "Sort: Artist")[sort],
                                false
                            ) { sort = (sort + 1) % 3 }
                        }
                    }
                }

                // Subtitle / count
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val countText = when {
                        !granted -> ""
                        inDetail || tab == "all" -> "${shown.size} songs"
                        tab == "artists" -> "${filteredArtists.size} artists"
                        tab == "albums" -> "${filteredAlbums.size} albums"
                        tab == "playlists" -> "${2 + pls.size} playlists"
                        else -> ""
                    }
                    Text(countText, color = pal.tx2, fontSize = 13.sp, modifier = Modifier.weight(1f))
                    if (!inDetail && tab == "playlists") {
                        Text(
                            "+ New playlist",
                            color = Accent,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier
                                .clickable {
                                    pendingAdd = null
                                    dlg = 1
                                }
                                .padding(vertical = 6.dp)
                        )
                    }
                }

                if (!granted) {
                    Column(
                        Modifier.fillMaxWidth().padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            "Tunes needs access to your music to build your library. Grant it in Settings, then tap refresh.",
                            color = pal.tx2,
                            fontSize = 15.sp
                        )
                        Spacer(Modifier.height(12.dp))
                        Button(
                            onClick = {
                                ctx.startActivity(
                                    Intent(
                                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                        Uri.fromParts("package", ctx.packageName, null)
                                    )
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Accent)
                        ) { Text("Open Settings") }
                    }
                } else if (inDetail) {
                    // Detail track list (artist / album / playlist)
                    if (shown.isEmpty()) {
                        Text(
                            when {
                                detail == "pl:$PL_RECENT" -> "Nothing played yet"
                                detail == "pl:$PL_FAV" -> "No favourites yet"
                                detail?.startsWith("pl:") == true -> "Empty playlist. Add songs from the player menu."
                                detail?.startsWith("artist:") == true -> "No songs"
                                detail?.startsWith("album:") == true -> "No songs"
                                else -> "No songs found"
                            },
                            color = pal.tx2,
                            fontSize = 15.sp,
                            modifier = Modifier.fillMaxWidth().padding(36.dp)
                        )
                    } else {
                        LazyColumn(
                            Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(
                                start = 16.dp,
                                end = 16.dp,
                                bottom = if (cur != null) 110.dp else 24.dp
                            ),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            itemsIndexed(
                                shown,
                                key = { _, t -> t.id },
                                contentType = { _, _ -> "track" }
                            ) { i, t ->
                                TrackRow(
                                    t = t,
                                    on = t.id == curId,
                                    showRemove = canEditPlaylist,
                                    onRemove = if (canEditPlaylist) {
                                        { removeFromCurrentPlaylist(t) }
                                    } else null
                                ) { playFrom(shown, i) }
                            }
                        }
                    }
                } else {
                    // Swipe between All / Artists / Albums / Playlists
                    HorizontalPager(
                        state = pagerState,
                        modifier = Modifier.fillMaxSize()
                    ) { page ->
                        when (page) {
                            0 -> {
                                // All songs
                                if (shown.isEmpty()) {
                                    Text(
                                        "No songs found",
                                        color = pal.tx2,
                                        fontSize = 15.sp,
                                        modifier = Modifier.fillMaxWidth().padding(36.dp)
                                    )
                                } else {
                                    LazyColumn(
                                        Modifier.fillMaxSize(),
                                        contentPadding = PaddingValues(
                                            start = 16.dp,
                                            end = 16.dp,
                                            bottom = if (cur != null) 110.dp else 24.dp
                                        ),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        itemsIndexed(
                                            shown,
                                            key = { _, t -> t.id },
                                            contentType = { _, _ -> "track" }
                                        ) { i, t ->
                                            TrackRow(t, t.id == curId) { playFrom(shown, i) }
                                        }
                                    }
                                }
                            }
                            1 -> {
                                if (filteredArtists.isEmpty()) {
                                    Text(
                                        "No artists found",
                                        color = pal.tx2,
                                        fontSize = 15.sp,
                                        modifier = Modifier.fillMaxWidth().padding(36.dp)
                                    )
                                } else {
                                    LazyColumn(
                                        Modifier.fillMaxSize(),
                                        contentPadding = PaddingValues(
                                            start = 16.dp,
                                            end = 16.dp,
                                            bottom = if (cur != null) 110.dp else 24.dp
                                        ),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        items(filteredArtists, key = { it }) { name ->
                                            val count = tracks.count { it.artist == name }
                                            GroupRow(
                                                name,
                                                "$count songs",
                                                Icons.Rounded.Person
                                            ) { detail = "artist:$name" }
                                        }
                                    }
                                }
                            }
                            2 -> {
                                if (filteredAlbums.isEmpty()) {
                                    Text(
                                        "No albums found",
                                        color = pal.tx2,
                                        fontSize = 15.sp,
                                        modifier = Modifier.fillMaxWidth().padding(36.dp)
                                    )
                                } else {
                                    LazyColumn(
                                        Modifier.fillMaxSize(),
                                        contentPadding = PaddingValues(
                                            start = 16.dp,
                                            end = 16.dp,
                                            bottom = if (cur != null) 110.dp else 24.dp
                                        ),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        items(
                                            filteredAlbums,
                                            key = { "${it.name}||${it.artist}" }
                                        ) { al ->
                                            GroupRow(
                                                al.name,
                                                "${al.artist} · ${al.count} songs",
                                                Icons.Rounded.Album
                                            ) { detail = "album:${al.name}||${al.artist}" }
                                        }
                                    }
                                }
                            }
                            else -> {
                                LazyColumn(
                                    Modifier.fillMaxSize(),
                                    contentPadding = PaddingValues(
                                        start = 16.dp,
                                        end = 16.dp,
                                        bottom = if (cur != null) 110.dp else 24.dp
                                    ),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    item(key = "recent") {
                                        GroupRow(
                                            "Recently Played",
                                            "${recentIds.count { it in trackById }} songs",
                                            Icons.Rounded.History
                                        ) { detail = "pl:$PL_RECENT" }
                                    }
                                    item(key = "fav") {
                                        GroupRow(
                                            "Favourites",
                                            "${favs.count { it.toLongOrNull() in trackById }} songs",
                                            Icons.Rounded.Favorite
                                        ) { detail = "pl:$PL_FAV" }
                                    }
                                    items(pls, key = { it.id }) { pl ->
                                        GroupRow(
                                            pl.name,
                                            "${pl.ids.count { it in trackById }} songs",
                                            Icons.Rounded.QueueMusic
                                        ) { detail = "pl:${pl.id}" }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Mini player
            if (cur != null) {
                val miniBg = if (pal === DarkPal) Color(0xFF1C1C1E) else Color.White
                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .clickable { showPlayer = true },
                    color = miniBg,
                    shadowElevation = 12.dp,
                    tonalElevation = 2.dp
                ) {
                    Column {
                        MiniBar(ps, total, Modifier)
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .navigationBarsPadding()
                                .padding(start = 14.dp, end = 6.dp, top = 10.dp, bottom = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Cover(cur, Modifier.size(52.dp), 8.dp)
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    cur.title,
                                    color = pal.tx,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 1,
                                    softWrap = false,
                                    modifier = Modifier.basicMarquee(iterations = Int.MAX_VALUE)
                                )
                                Text(
                                    cur.artist,
                                    color = pal.tx2,
                                    fontSize = 14.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            IconBtn(
                                if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                box = 52.dp,
                                size = 32.dp
                            ) { togglePlay() }
                        }
                    }
                }
            }

            // New playlist dialog
            if (dlg == 1) {
                var name by remember { mutableStateOf("") }
                AlertDialog(
                    onDismissRequest = { dlg = 0; pendingAdd = null },
                    containerColor = pal.card,
                    title = { Text("New playlist", color = pal.tx) },
                    text = {
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(pal.fill)
                                .padding(12.dp)
                        ) {
                            if (name.isEmpty()) Text("Name", color = pal.tx2, fontSize = 17.sp)
                            BasicTextField(
                                name,
                                { name = it },
                                singleLine = true,
                                textStyle = TextStyle(color = pal.tx, fontSize = 17.sp),
                                cursorBrush = SolidColor(Accent),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            val n = name.trim()
                            if (n.isNotEmpty()) {
                                val first = pendingAdd
                                val pl = Pl(
                                    System.currentTimeMillis().toString(),
                                    n,
                                    if (first != null) listOf(first.id) else emptyList()
                                )
                                savePls(pls + pl)
                                if (first == null) {
                                    tab = "playlists"
                                    detail = "pl:${pl.id}"
                                }
                            }
                            dlg = 0
                            pendingAdd = null
                        }) { Text("Create", color = Accent) }
                    },
                    dismissButton = {
                        TextButton(onClick = { dlg = 0; pendingAdd = null }) {
                            Text("Cancel", color = pal.tx2)
                        }
                    }
                )
            }

            // Add to playlist dialog
            if (dlg == 2 && cur != null) {
                AlertDialog(
                    onDismissRequest = { dlg = 0 },
                    containerColor = pal.card,
                    title = { Text("Add to playlist", color = pal.tx) },
                    text = {
                        Column {
                            // Favourites toggle
                            val inFav = cur.id.toString() in favs
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clickable { toggleFav(cur) }
                                    .padding(vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Favourites", color = pal.tx, fontSize = 16.sp, modifier = Modifier.weight(1f))
                                if (inFav) Icon(Icons.Rounded.Check, null, tint = Accent)
                            }
                            pls.forEach { pl ->
                                val has = cur.id in pl.ids
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            savePls(pls.map {
                                                if (it.id == pl.id)
                                                    it.copy(ids = if (has) it.ids - cur.id else it.ids + cur.id)
                                                else it
                                            })
                                        }
                                        .padding(vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(pl.name, color = pal.tx, fontSize = 16.sp, modifier = Modifier.weight(1f))
                                    if (has) Icon(Icons.Rounded.Check, null, tint = Accent)
                                }
                            }
                            Text(
                                "New playlist...",
                                color = Accent,
                                fontSize = 16.sp,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        pendingAdd = cur
                                        dlg = 1
                                    }
                                    .padding(vertical = 12.dp)
                            )
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = { dlg = 0 }) { Text("Done", color = Accent) }
                    }
                )
            }

            // Full player
            val c = cur
            if (c != null) {
                AnimatedVisibility(
                    visible = showPlayer,
                    enter = slideInVertically(tween(280)) { it },
                    exit = slideOutVertically(tween(220)) { it }
                ) {
                    val dark = pal === DarkPal
                    val base = coverColor(c)
                    val bgc = if (dark) Color(0xFF0B0B14) else Color(0xFFF7F7FB)
                    val fg = if (dark) Color.White else Color(0xFF111114)
                    val fg2 = fg.copy(alpha = .6f)
                    val brush = Brush.verticalGradient(
                        listOf(
                            lerp(bgc, base, if (dark) .22f else .18f),
                            lerp(bgc, base, if (dark) .45f else .32f),
                            lerp(bgc, base, if (dark) .18f else .14f)
                        )
                    )
                    var menu by remember { mutableStateOf(false) }
                    val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
                    val maxV = remember { am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
                    var vol by remember {
                        mutableFloatStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxV)
                    }
                    var volDrag by remember { mutableStateOf(false) }
                    LaunchedEffect(Unit) {
                        while (true) {
                            if (!volDrag) {
                                vol = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxV
                            }
                            delay(600)
                        }
                    }
                    val fav = c.id.toString() in favs
                    val dragY = remember { Animatable(0f) }
                    val dragScope = rememberCoroutineScope()
                    val closePx = with(LocalDensity.current) { 140.dp.toPx() }
                    val dragState = rememberDraggableState { d ->
                        dragScope.launch { dragY.snapTo((dragY.value + d).coerceAtLeast(0f)) }
                    }
                    val pullDown = Modifier.draggable(
                        state = dragState,
                        orientation = Orientation.Vertical,
                        onDragStopped = { v ->
                            if (dragY.value > closePx || v > 1200f) {
                                showPlayer = false
                            } else {
                                dragY.animateTo(0f, spring(stiffness = Spring.StiffnessMediumLow))
                            }
                        }
                    )

                    Column(
                        Modifier
                            .fillMaxSize()
                            .offset { IntOffset(0, dragY.value.roundToInt()) }
                            .background(brush)
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) {}
                            .statusBarsPadding()
                            .navigationBarsPadding()
                    ) {
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .then(pullDown),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { showPlayer = false }
                                    .padding(horizontal = 24.dp, vertical = 14.dp)
                            ) {
                                Box(
                                    Modifier
                                        .width(40.dp)
                                        .height(5.dp)
                                        .clip(RoundedCornerShape(3.dp))
                                        .background(fg2.copy(alpha = .5f))
                                )
                            }
                        }
                        BoxWithConstraints(
                            Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .then(pullDown)
                                .padding(horizontal = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            val sz = minOf(maxWidth, maxHeight)
                            Cover(
                                c,
                                Modifier.size(sz).shadow(24.dp, RoundedCornerShape(22.dp)),
                                22.dp,
                                big = true
                            )
                        }
                        Column(Modifier.padding(horizontal = 24.dp)) {
                            Spacer(Modifier.height(16.dp))
                            Row(
                                Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        c.title,
                                        color = fg,
                                        fontSize = 26.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        c.artist,
                                        color = fg2,
                                        fontSize = 20.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Box {
                                    Box(
                                        Modifier
                                            .size(38.dp)
                                            .clip(CircleShape)
                                            .background(fg.copy(alpha = .18f))
                                            .clickable { menu = true },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            Icons.Rounded.MoreHoriz,
                                            null,
                                            tint = fg,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                    DropdownMenu(
                                        expanded = menu,
                                        onDismissRequest = { menu = false },
                                        modifier = Modifier.background(pal.card, RoundedCornerShape(16.dp))
                                    ) {
                                        Column(
                                            Modifier
                                                .widthIn(min = 200.dp)
                                                .padding(horizontal = 16.dp, vertical = 12.dp)
                                        ) {
                                            Text(
                                                c.artist,
                                                color = pal.tx,
                                                fontSize = 16.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Spacer(Modifier.height(2.dp))
                                            Text(
                                                c.album,
                                                color = pal.tx2,
                                                fontSize = 14.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                        Box(Modifier.fillMaxWidth().height(1.dp).background(pal.fill))
                                        DropdownMenuItem(
                                            text = {
                                                Text(
                                                    "Playlist",
                                                    color = pal.tx,
                                                    fontSize = 16.sp,
                                                    fontWeight = FontWeight.Medium
                                                )
                                            },
                                            onClick = { menu = false; dlg = 2 },
                                            leadingIcon = {
                                                Icon(Icons.Rounded.QueueMusic, null, tint = Accent)
                                            }
                                        )
                                    }
                                }
                            }
                            Spacer(Modifier.height(10.dp))
                            PlayerSeek(ps, total, fg, { dragging = true }, { v ->
                                player?.seekTo(v)
                                dragging = false
                            })
                            Spacer(Modifier.height(6.dp))
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconBtn(
                                    Icons.Rounded.Shuffle,
                                    if (shuffle) fg else fg2
                                ) { player?.shuffleModeEnabled = !shuffle }
                                IconBtn(Icons.Rounded.FastRewind, fg, box = 64.dp, size = 46.dp) {
                                    player?.seekToPrevious()
                                }
                                IconBtn(
                                    if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                    fg,
                                    box = 84.dp,
                                    size = 62.dp
                                ) { togglePlay() }
                                IconBtn(Icons.Rounded.FastForward, fg, box = 64.dp, size = 46.dp) {
                                    player?.seekToNext()
                                }
                                IconBtn(
                                    if (repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne
                                    else Icons.Rounded.Repeat,
                                    if (repeat == Player.REPEAT_MODE_OFF) fg2 else fg
                                ) {
                                    player?.repeatMode = when (repeat) {
                                        Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                                        Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                                        else -> Player.REPEAT_MODE_OFF
                                    }
                                }
                            }
                            Spacer(Modifier.height(10.dp))
                            Row(
                                Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Rounded.VolumeDown,
                                    null,
                                    tint = fg2,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(Modifier.width(10.dp))
                                Box(Modifier.weight(1f)) {
                                    Bar(
                                        vol,
                                        fg,
                                        false,
                                        { f ->
                                            volDrag = true
                                            vol = f
                                            am.setStreamVolume(
                                                AudioManager.STREAM_MUSIC,
                                                (f * maxV).roundToInt(),
                                                0
                                            )
                                        },
                                        { volDrag = false }
                                    )
                                }
                                Spacer(Modifier.width(10.dp))
                                Icon(
                                    Icons.Rounded.VolumeUp,
                                    null,
                                    tint = fg2,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(Modifier.height(8.dp))
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconBtn(
                                    if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                                    if (fav) Accent else fg2
                                ) { toggleFav(c) }
                            }
                            // Up next from the current queue
                            val nextSongs = remember(player, curId, isPlaying, tracks) {
                                val p = player ?: return@remember emptyList<Track>()
                                val count = p.mediaItemCount
                                val idx = p.currentMediaItemIndex
                                if (idx < 0 || count <= 0) return@remember emptyList()
                                val byId = tracks.associateBy { it.id }
                                (1..4).mapNotNull { off ->
                                    val i = idx + off
                                    if (i >= count) null
                                    else {
                                        val id = p.getMediaItemAt(i).mediaId?.toLongOrNull()
                                        id?.let { byId[it] }
                                    }
                                }
                            }
                            if (nextSongs.isNotEmpty()) {
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    "Up next",
                                    color = fg2,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(horizontal = 4.dp)
                                )
                                Spacer(Modifier.height(4.dp))
                                nextSongs.forEachIndexed { i, t ->
                                    Row(
                                        Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(10.dp))
                                            .clickable {
                                                val p = player ?: return@clickable
                                                p.seekTo(p.currentMediaItemIndex + i + 1, 0L)
                                            }
                                            .padding(horizontal = 4.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            "${i + 1}",
                                            color = fg2,
                                            fontSize = 13.sp,
                                            modifier = Modifier.width(22.dp)
                                        )
                                        Column(Modifier.weight(1f)) {
                                            Text(
                                                t.title,
                                                color = fg,
                                                fontSize = 15.sp,
                                                fontWeight = FontWeight.Medium,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                t.artist,
                                                color = fg2,
                                                fontSize = 13.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                        Text(fmt(t.dur), color = fg2, fontSize = 13.sp)
                                    }
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                        }
                    }
                }
            }
        }
    }
}
